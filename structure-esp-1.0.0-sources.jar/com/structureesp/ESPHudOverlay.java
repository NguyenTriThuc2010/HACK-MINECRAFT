package com.structureesp;

import java.util.List;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

/**
 * Renders a 2D HUD overlay showing structure names and distances,
 * sorted by proximity (closest first). Max 8 entries.
 */
public class ESPHudOverlay {

    private static final int MAX_ENTRIES = 8;
    private static final int PADDING = 6;
    private static final int LINE_HEIGHT = 14;
    private static final int MARGIN_X = 10;
    private static final int MARGIN_Y = 10;

    public void render(class_332 drawContext, List<StructureData> structures) {
        if (structures.isEmpty()) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        class_327 textRenderer = client.field_1772;
        class_243 playerPos = client.field_1724.method_19538();

        // Update distances
        for (StructureData s : structures) {
            s.updateDistance(playerPos);
        }

        // Render at most MAX_ENTRIES
        int count = Math.min(structures.size(), MAX_ENTRIES);

        // Calculate panel dimensions
        int maxTextWidth = 0;
        String[] lines = new String[count];
        int[] colors = new int[count];

        for (int i = 0; i < count; i++) {
            StructureData s = structures.get(i);
            int dist = (int) s.getDistanceToPlayer();
            lines[i] = String.format("§l%s§r — %d blocks", s.getName(), dist);
            colors[i] = s.getColor();
            int w = textRenderer.method_1727(lines[i]);
            if (w > maxTextWidth) maxTextWidth = w;
        }

        int panelWidth = maxTextWidth + PADDING * 2 + 12; // 12 for color indicator
        int panelHeight = count * LINE_HEIGHT + PADDING * 2 + LINE_HEIGHT; // extra for header

        // Draw background panel
        int bgX = MARGIN_X;
        int bgY = MARGIN_Y;
        drawContext.method_25294(bgX, bgY, bgX + panelWidth, bgY + panelHeight, 0x88000000);

        // Draw border
        drawContext.method_25294(bgX, bgY, bgX + panelWidth, bgY + 1, 0xFF00FFFF); // top
        drawContext.method_25294(bgX, bgY + panelHeight - 1, bgX + panelWidth, bgY + panelHeight, 0xFF00FFFF); // bottom
        drawContext.method_25294(bgX, bgY, bgX + 1, bgY + panelHeight, 0xFF00FFFF); // left
        drawContext.method_25294(bgX + panelWidth - 1, bgY, bgX + panelWidth, bgY + panelHeight, 0xFF00FFFF); // right

        // Header
        String header = "§b§l⚡ Structure ESP";
        drawContext.method_51433(textRenderer, header, bgX + PADDING, bgY + PADDING, 0x00FFFF, true);

        // Draw entries
        for (int i = 0; i < count; i++) {
            int textY = bgY + PADDING + LINE_HEIGHT + i * LINE_HEIGHT;

            // Color indicator square
            int indicatorX = bgX + PADDING;
            int indicatorY = textY + 1;
            drawContext.method_25294(indicatorX, indicatorY, indicatorX + 8, indicatorY + 8, 0xFF000000 | colors[i]);

            // Text
            drawContext.method_51433(textRenderer, lines[i], indicatorX + 12, textY, 0xFFFFFF, true);
        }
    }
}
