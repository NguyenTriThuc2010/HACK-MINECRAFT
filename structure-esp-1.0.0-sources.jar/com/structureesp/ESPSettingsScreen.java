package com.structureesp;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ESPSettingsScreen extends class_437 {
    private final class_437 parent;

    protected ESPSettingsScreen(class_437 parent) {
        super(class_2561.method_43470("Structure ESP Settings"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int buttonWidth = 200;
        int buttonHeight = 20;
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;

        // ESP Toggle Button
        this.method_37063(class_4185.method_46430(getToggleText(), button -> {
            ModConfig config = ModConfig.get();
            config.espEnabled = !config.espEnabled;
            config.save();
            button.method_25355(getToggleText());
        })
        .method_46434(centerX - buttonWidth / 2, centerY - 65, buttonWidth, buttonHeight)
        .method_46431());

        // Line ESP Toggle Button
        this.method_37063(class_4185.method_46430(getLineToggleText(), button -> {
            ModConfig config = ModConfig.get();
            config.lineEnabled = !config.lineEnabled;
            config.save();
            button.method_25355(getLineToggleText());
        })
        .method_46434(centerX - buttonWidth / 2, centerY - 40, buttonWidth, buttonHeight)
        .method_46431());

        // Chest ESP Toggle Button
        this.method_37063(class_4185.method_46430(getChestToggleText(), button -> {
            ModConfig config = ModConfig.get();
            config.chestEspEnabled = !config.chestEspEnabled;
            config.save();
            button.method_25355(getChestToggleText());
        })
        .method_46434(centerX - buttonWidth / 2, centerY - 15, buttonWidth, buttonHeight)
        .method_46431());

        // Trial Chambers Toggle Button
        this.method_37063(class_4185.method_46430(getTrialToggleText(), button -> {
            ModConfig config = ModConfig.get();
            config.trialChambersHeuristicEnabled = !config.trialChambersHeuristicEnabled;
            config.save();
            button.method_25355(getTrialToggleText());
        })
        .method_46434(centerX - buttonWidth / 2, centerY + 10, buttonWidth, buttonHeight)
        .method_46431());

        // X-Ray Toggle Button
        this.method_37063(class_4185.method_46430(getXrayToggleText(), button -> {
            StructureESPMod.toggleXray();
            button.method_25355(getXrayToggleText());
        })
        .method_46434(centerX - buttonWidth / 2, centerY + 35, buttonWidth, buttonHeight)
        .method_46431());

        // X-Ray Filter Menu Button
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Filter Ores..."), button -> {
            this.field_22787.method_1507(new XRayFilterScreen(this));
        })
        .method_46434(centerX - buttonWidth / 2, centerY + 60, buttonWidth, buttonHeight)
        .method_46431());

        // X-Ray Bypass Toggle Button
        this.method_37063(class_4185.method_46430(getBypassToggleText(), button -> {
            ModConfig config = ModConfig.get();
            config.xrayBypass = !config.xrayBypass;
            config.save();
            button.method_25355(getBypassToggleText());
        })
        .method_46434(centerX - buttonWidth / 2, centerY + 85, buttonWidth, buttonHeight)
        .method_46431());

        // HUD Toggle Button
        this.method_37063(class_4185.method_46430(getHudToggleText(), button -> {
            ModConfig config = ModConfig.get();
            config.hudEnabled = !config.hudEnabled;
            config.save();
            button.method_25355(getHudToggleText());
        })
        .method_46434(centerX - buttonWidth / 2, centerY + 110, buttonWidth, buttonHeight)
        .method_46431());

        // Back/Done Button
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), button -> {
            this.field_22787.method_1507(this.parent);
        })
        .method_46434(centerX - buttonWidth / 2, centerY + 140, buttonWidth, buttonHeight)
        .method_46431());
    }

    private class_2561 getToggleText() {
        boolean enabled = ModConfig.get().espEnabled;
        return class_2561.method_43470("Structure ESP: " + (enabled ? "§a§lON" : "§c§lOFF"));
    }

    private class_2561 getLineToggleText() {
        boolean enabled = ModConfig.get().lineEnabled;
        return class_2561.method_43470("ESP Lines: " + (enabled ? "§a§lON" : "§c§lOFF"));
    }

    private class_2561 getChestToggleText() {
        boolean enabled = ModConfig.get().chestEspEnabled;
        return class_2561.method_43470("Chest ESP: " + (enabled ? "§a§lON" : "§c§lOFF"));
    }

    private class_2561 getTrialToggleText() {
        boolean enabled = ModConfig.get().trialChambersHeuristicEnabled;
        return class_2561.method_43470("Trial Chambers Detection: " + (enabled ? "§a§lON" : "§c§lOFF"));
    }

    private class_2561 getLineWidthText() {
        return class_2561.method_43470("Line Thickness: §e" + String.format("%.1f", ModConfig.get().lineWidth));
    }

    private class_2561 getHudToggleText() {
        boolean enabled = ModConfig.get().hudEnabled;
        return class_2561.method_43470("HUD Overlay: " + (enabled ? "§a§lON" : "§c§lOFF"));
    }

    private class_2561 getXrayToggleText() {
        boolean enabled = ModConfig.get().xrayEnabled;
        return class_2561.method_43470("X-Ray: " + (enabled ? "§a§lON" : "§c§lOFF"));
    }

    private class_2561 getBypassToggleText() {
        boolean enabled = ModConfig.get().xrayBypass;
        return class_2561.method_43470("Anti X-Ray Bypass: " + (enabled ? "§a§lON" : "§c§lOFF"));
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        
        // Draw Title with custom styling
        context.method_25300(this.field_22793, "§b§l⚡ Structure ESP Settings ⚡", this.field_22789 / 2, this.field_22790 / 2 - 85, 0xFFFFFF);
        
        // Background panel for buttons
        int panelWidth = 220;
        int panelHeight = 230;
        int panelX = (this.field_22789 - panelWidth) / 2;
        int panelY = (this.field_22790 - panelHeight) / 2 - 10;
        context.method_25294(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0x66000000);
        
        super.method_25394(context, mouseX, mouseY, delta);
    }
}
