package com.structureesp;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class ModConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static File configFile;

    public boolean espEnabled = true;
    public boolean lineEnabled = true;
    public boolean chestEspEnabled = true;
    public boolean trialChambersHeuristicEnabled = true;
    public boolean xrayEnabled = false;
    public boolean xrayBypass = true;
    public Set<String> xrayFilter = new HashSet<>(Arrays.asList(
            "minecraft:diamond_ore", "minecraft:deepslate_diamond_ore",
            "minecraft:gold_ore", "minecraft:deepslate_gold_ore",
            "minecraft:iron_ore", "minecraft:deepslate_iron_ore",
            "minecraft:coal_ore", "minecraft:deepslate_coal_ore",
            "minecraft:copper_ore", "minecraft:deepslate_copper_ore",
            "minecraft:lapis_ore", "minecraft:deepslate_lapis_ore",
            "minecraft:emerald_ore", "minecraft:deepslate_emerald_ore",
            "minecraft:redstone_ore", "minecraft:deepslate_redstone_ore",
            "minecraft:ancient_debris", "minecraft:netherite_block", "minecraft:spawner",
            "minecraft:chest", "minecraft:barrel", "minecraft:shulker_box",
            "minecraft:gilded_blackstone", "minecraft:nether_gold_ore",
            "minecraft:raw_iron_block", "minecraft:raw_gold_block", "minecraft:raw_copper_block"
    ));
    public boolean hudEnabled = true;
    public float lineWidth = 2.0f;
    public int hudX = 10;
    public int hudY = 10;

    private static ModConfig instance;

    public static ModConfig get() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    private static ModConfig load() {
        configFile = new File(FabricLoader.getInstance().getConfigDir().toFile(), "structure-esp.json");
        if (configFile.exists()) {
            try (FileReader reader = new FileReader(configFile)) {
                return GSON.fromJson(reader, ModConfig.class);
            } catch (IOException e) {
                StructureESPMod.LOGGER.error("Failed to load config", e);
            }
        }
        return new ModConfig();
    }

    public void save() {
        try (FileWriter writer = new FileWriter(configFile)) {
            GSON.toJson(this, writer);
        } catch (IOException e) {
            StructureESPMod.LOGGER.error("Failed to save config", e);
        }
    }
}
