package com.structureesp;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StructureESPMod implements ClientModInitializer {

    public static final String MOD_ID = "structure-esp";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static class_304 menuKey;

    private static StructureLocator locator;
    private static ESPRenderer renderer;
    private static ESPHudOverlay hudOverlay;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[StructureESP] Initializing...");

        // Load config
        ModConfig config = ModConfig.get();
        config.save(); // Ensure all fields are present in file
        LOGGER.info("[StructureESP] Config loaded & saved — ESP enabled: {}, HUD enabled: {}", 
                config.espEnabled, config.hudEnabled);

        // Register keybind: Right Shift to open menu
        menuKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.structureesp.menu",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.structureesp"
        ));

        // Initialize components
        locator = new StructureLocator();
        renderer = new ESPRenderer();
        hudOverlay = new ESPHudOverlay();

        // Tick event — update structures + handle keybinds
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Open Menu
            while (menuKey.method_1436()) {
                client.method_1507(new ESPSettingsScreen(null));
            }

            // Update structure scan
            ModConfig conf = ModConfig.get();
            if (conf.espEnabled && client.field_1687 != null && client.field_1724 != null) {
                locator.tick(client);
            }
        });

        // World render event — draw 3D ESP boxes
        WorldRenderEvents.LAST.register(context -> {
            ModConfig conf = ModConfig.get();
            if (conf.espEnabled) {
                renderer.render(context, locator.getStructures());
            }
        });

        // HUD render event — draw 2D overlay
        HudRenderCallback.EVENT.register((drawContext, renderTickCounter) -> {
            ModConfig conf = ModConfig.get();
            if (conf.espEnabled && conf.hudEnabled) {
                hudOverlay.render(drawContext, locator.getStructures());
            }
        });

        LOGGER.info("[StructureESP] Initialized! Press Right Shift for Menu.");
    }

    public static boolean isEspEnabled() {
        return ModConfig.get().espEnabled;
    }

    public static void toggleXray() {
        ModConfig config = ModConfig.get();
        config.xrayEnabled = !config.xrayEnabled;
        config.save();
        
        class_310 client = class_310.method_1551();
        if (client.field_1769 != null) {
            client.field_1769.method_3279();
        }
    }
}
