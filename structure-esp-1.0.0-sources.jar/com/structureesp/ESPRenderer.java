package com.structureesp;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_10142;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_3341;
import net.minecraft.class_4587;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;

import java.util.List;

/**
 * Renders 3D bounding boxes and waypoint lines for detected structures in world space.
 * Optimized to use relative coordinates to avoid float precision issues.
 */
public class ESPRenderer {

    public void render(WorldRenderContext context, List<StructureData> structures) {
        if (structures.isEmpty()) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        class_4587 matrices = context.matrixStack();
        class_243 cameraPos = context.camera().method_19326();

        // Setup render state
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest(); // ESP See-through
        RenderSystem.setShader(class_10142.field_53876);

        // We do NOT matrices.translate(-cameraPos) here anymore.
        // Instead, we subtract cameraPos from coordinates inside the draw methods.
        // This keeps the values small and prevents jitter at high coordinates.

        for (StructureData structure : structures) {
            float r = structure.getRed();
            float g = structure.getGreen();
            float b = structure.getBlue();
            
            // 1. Draw Boxes
            drawFilledBox(matrices, structure.getBoundingBox(), cameraPos, r, g, b, 0.15f);
            drawBoxOutline(matrices, structure.getBoundingBox(), cameraPos, r, g, b, 0.8f);

            // 2. Draw Waypoint Line
            if (ModConfig.get().lineEnabled) {
                // Draw from slightly below camera center to structure center
                class_243 lineStart = new class_243(0, -0.1, 0); // Relative to camera
                class_243 lineEnd = structure.getCenter().method_1020(cameraPos); // Relative to camera
                
                drawLine(matrices, lineStart, lineEnd, r, g, b, 0.6f);
            }
        }

        // Restore state
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private void drawFilledBox(class_4587 matrices, class_3341 box, class_243 cameraPos, float r, float g, float b, float a) {
        float x1 = (float) (box.method_35415() - cameraPos.field_1352);
        float y1 = (float) (box.method_35416() - cameraPos.field_1351);
        float z1 = (float) (box.method_35417() - cameraPos.field_1350);
        float x2 = (float) (box.method_35418() + 1 - cameraPos.field_1352);
        float y2 = (float) (box.method_35419() + 1 - cameraPos.field_1351);
        float z2 = (float) (box.method_35420() + 1 - cameraPos.field_1350);

        Matrix4f matrix = matrices.method_23760().method_23761();
        class_289 tessellator = class_289.method_1348();
        class_287 buffer = tessellator.method_60827(class_293.class_5596.field_27382, class_290.field_1576);

        // Bottom face
        buffer.method_22918(matrix, x1, y1, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y1, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y1, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x1, y1, z2).method_22915(r, g, b, a);
        // Top face
        buffer.method_22918(matrix, x1, y2, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x1, y2, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y2, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y2, z1).method_22915(r, g, b, a);
        // North
        buffer.method_22918(matrix, x1, y1, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x1, y2, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y2, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y1, z1).method_22915(r, g, b, a);
        // South
        buffer.method_22918(matrix, x1, y1, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y1, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y2, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x1, y2, z2).method_22915(r, g, b, a);
        // West
        buffer.method_22918(matrix, x1, y1, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x1, y1, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x1, y2, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x1, y2, z1).method_22915(r, g, b, a);
        // East
        buffer.method_22918(matrix, x2, y1, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y2, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y2, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y1, z2).method_22915(r, g, b, a);

        class_286.method_43433(buffer.method_60800());
    }

    private void drawBoxOutline(class_4587 matrices, class_3341 box, class_243 cameraPos, float r, float g, float b, float a) {
        float x1 = (float) (box.method_35415() - cameraPos.field_1352);
        float y1 = (float) (box.method_35416() - cameraPos.field_1351);
        float z1 = (float) (box.method_35417() - cameraPos.field_1350);
        float x2 = (float) (box.method_35418() + 1 - cameraPos.field_1352);
        float y2 = (float) (box.method_35419() + 1 - cameraPos.field_1351);
        float z2 = (float) (box.method_35420() + 1 - cameraPos.field_1350);

        Matrix4f matrix = matrices.method_23760().method_23761();
        RenderSystem.lineWidth(ModConfig.get().lineWidth);

        class_289 tessellator = class_289.method_1348();
        class_287 buffer = tessellator.method_60827(class_293.class_5596.field_29344, class_290.field_1576);

        // Bottom edges
        buffer.method_22918(matrix, x1, y1, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y1, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y1, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y1, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y1, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x1, y1, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x1, y1, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x1, y1, z1).method_22915(r, g, b, a);

        // Top edges
        buffer.method_22918(matrix, x1, y2, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y2, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y2, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y2, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y2, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x1, y2, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x1, y2, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x1, y2, z1).method_22915(r, g, b, a);

        // Vertical edges
        buffer.method_22918(matrix, x1, y1, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x1, y2, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y1, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y2, z1).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y1, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x2, y2, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x1, y1, z2).method_22915(r, g, b, a);
        buffer.method_22918(matrix, x1, y2, z2).method_22915(r, g, b, a);

        class_286.method_43433(buffer.method_60800());
    }

    private void drawLine(class_4587 matrices, class_243 from, class_243 to, float r, float g, float b, float a) {
        Matrix4f matrix = matrices.method_23760().method_23761();

        RenderSystem.lineWidth(ModConfig.get().lineWidth * 0.75f);

        class_289 tessellator = class_289.method_1348();
        class_287 buffer = tessellator.method_60827(class_293.class_5596.field_29344, class_290.field_1576);

        // 'from' and 'to' are already relative to camera
        buffer.method_22918(matrix, (float) from.field_1352, (float) from.field_1351, (float) from.field_1350).method_22915(r, g, b, a);
        buffer.method_22918(matrix, (float) to.field_1352, (float) to.field_1351, (float) to.field_1350).method_22915(r, g, b, a);

        class_286.method_43433(buffer.method_60800());
    }
}
