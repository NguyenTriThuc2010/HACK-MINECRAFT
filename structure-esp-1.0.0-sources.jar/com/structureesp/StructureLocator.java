package com.structureesp;

import com.structureesp.mixin.ChunkAccessor;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2627;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_310;
import net.minecraft.class_3195;
import net.minecraft.class_3341;
import net.minecraft.class_3443;
import net.minecraft.class_3449;
import net.minecraft.class_3719;
import net.minecraft.class_638;

/**
 * Scans loaded chunks for underground structure starts and caches results.
 * Re-scans every ~40 ticks (2 seconds).
 */
public class StructureLocator {

    // Structure registry keys → display info
    private static final Map<String, StructureInfo> TARGET_STRUCTURES = new LinkedHashMap<>();

    static {
        TARGET_STRUCTURES.put("minecraft:trial_chambers",  new StructureInfo("Trial Chamber",  0x00FFFF));
        TARGET_STRUCTURES.put("minecraft:stronghold",      new StructureInfo("Stronghold",      0xFFD700));
        TARGET_STRUCTURES.put("minecraft:mineshaft",       new StructureInfo("Mineshaft",       0x8B4513));
        TARGET_STRUCTURES.put("minecraft:mineshaft_mesa",  new StructureInfo("Mesa Mineshaft",  0xCD853F));
        TARGET_STRUCTURES.put("minecraft:ancient_city",    new StructureInfo("Ancient City",    0x191970));
        TARGET_STRUCTURES.put("minecraft:monster_room",    new StructureInfo("Dungeon",         0xFF4444));
        TARGET_STRUCTURES.put("minecraft:fortress",        new StructureInfo("Nether Fortress", 0x8B0000));
    }

    private final List<StructureData> structures = new CopyOnWriteArrayList<>();
    private int tickCounter = 0;
    private static final int SCAN_INTERVAL = 5; // ticks (~0.25 sec)

    public void tick(class_310 client) {
        tickCounter++;
        if (tickCounter < SCAN_INTERVAL) return;
        tickCounter = 0;

        class_638 world = client.field_1687;
        if (world == null || client.field_1724 == null) return;

        class_243 playerPos = client.field_1724.method_19538();
        int renderDistance = client.field_1690.method_42503().method_41753();

        // Player chunk position
        int playerChunkX = (int) playerPos.field_1352 >> 4;
        int playerChunkZ = (int) playerPos.field_1350 >> 4;

        List<StructureData> found = new ArrayList<>();
        Set<String> seenKeys = new HashSet<>(); // avoid duplicate bounding boxes

        // Scan all chunks within render distance
        int chunksScanned = 0;
        for (int cx = playerChunkX - renderDistance; cx <= playerChunkX + renderDistance; cx++) {
            for (int cz = playerChunkZ - renderDistance; cz <= playerChunkZ + renderDistance; cz++) {
                chunksScanned++;
                try {
                    class_2818 chunk = world.method_2935().method_21730(cx, cz);
                    if (chunk == null) continue;

                    Map<class_3195, class_3449> starts = ((ChunkAccessor) chunk).getStructureStarts();
                    boolean foundInRegistry = false;
                    // Iterate all structure starts in this chunk
                    for (Map.Entry<class_3195, class_3449> entry : starts.entrySet()) {
                        class_3195 structure = entry.getKey();
                        class_3449 start = entry.getValue();
                        if (start == null || !start.method_16657()) continue;

                        // Try to match against our target list
                        // Get the structure's registry key by checking the world registry
                        String structureId = getStructureId(world, structure);
                        if (structureId == null) continue;

                        StructureInfo info = TARGET_STRUCTURES.get(structureId);
                        if (info == null) continue;

                        // Process each structure piece for its bounding box
                        for (class_3443 piece : start.method_14963()) {
                            class_3341 box = piece.method_14935();
                            String uniqueKey = structureId + "_" + box.method_35415() + "_" + box.method_35416() + "_" + box.method_35417();

                            if (seenKeys.contains(uniqueKey)) continue;
                            seenKeys.add(uniqueKey);

                            StructureData data = new StructureData(
                                    info.name, structureId, box, info.color
                            );
                            data.updateDistance(playerPos);
                            found.add(data);
                            foundInRegistry = true;
                        }
                    }
                    // 2. If no structure data, fallback to block-based detection for Ancient City
                    if (!foundInRegistry) { 
                        detectAncientCityByBlocks(chunk, playerPos, found, seenKeys);
                    }

                    // 3. Trial Chambers Heuristic (Copper blocks)
                    if (ModConfig.get().trialChambersHeuristicEnabled) {
                        detectTrialChambersByBlocks(chunk, playerPos, found, seenKeys);
                    }

                    // 4. Chest ESP
                    if (ModConfig.get().chestEspEnabled) {
                        scanChestsInChunk(chunk, playerPos, found);
                    }
                } catch (Exception e) {
                    StructureESPMod.LOGGER.error("[StructureESP] Error scanning chunk {}, {}: {}", cx, cz, e.getMessage());
                }
            }
        }

        // Sort by distance
        found.sort(Comparator.comparingDouble(StructureData::getDistanceToPlayer));

        // Atomically replace
        if (!found.isEmpty() || !structures.isEmpty()) {
            StructureESPMod.LOGGER.info("[StructureESP] Scanned {} chunks, found {} structures.", chunksScanned, found.size());
        }
        structures.clear();
        structures.addAll(found);
    }

    /**
     * Heuristic detection for Ancient City based on signature blocks.
     */
    private void detectAncientCityByBlocks(class_2818 chunk, class_243 playerPos, List<StructureData> found, Set<String> seenKeys) {
        // Ancient cities are deep underground
        int minHeight = -64;
        int maxHeight = -20;

        boolean hasDeepslateTiles = false;
        boolean hasAncientCityIndicator = false; // Candle or Soul Lantern

        // Check chunk sections at deep levels
        class_2826[] sections = chunk.method_12006();
        for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
            class_2826 section = sections[sectionIndex];
            if (section == null || section.method_38292()) continue;
            
            int sectionY = chunk.method_31604(sectionIndex) << 4;
            if (sectionY < minHeight || sectionY > maxHeight) continue;

            // More thorough scan
            for (int x = 0; x < 16; x += 2) {
                for (int y = 0; y < 16; y += 2) {
                    for (int z = 0; z < 16; z += 2) {
                        class_2680 state = section.method_12254(x, y, z);
                        if (state.method_27852(class_2246.field_28896)) {
                            hasDeepslateTiles = true;
                        } else if (state.method_27852(class_2246.field_27099) || state.method_27852(class_2246.field_22110)) {
                            hasAncientCityIndicator = true;
                        }
                        
                        if (hasDeepslateTiles && hasAncientCityIndicator) break;
                    }
                    if (hasDeepslateTiles && hasAncientCityIndicator) break;
                }
                if (hasDeepslateTiles && hasAncientCityIndicator) break;
            }
            if (hasDeepslateTiles && hasAncientCityIndicator) break;
        }

        if (hasDeepslateTiles && hasAncientCityIndicator) {
            // Only add if we haven't added an Ancient City box very close by (within 2 chunks)
            String uniqueKey = "fallback_ancient_city_" + (chunk.method_12004().field_9181 / 3) + "_" + (chunk.method_12004().field_9180 / 3);
            if (seenKeys.contains(uniqueKey)) return;
            seenKeys.add(uniqueKey);

            StructureESPMod.LOGGER.info("[StructureESP] Heuristic MATCH for Ancient City at chunk {}, {}", chunk.method_12004().field_9181, chunk.method_12004().field_9180);

            // Create a general box for this chunk area
            class_3341 box = new class_3341(
                chunk.method_12004().method_8326(), -51, chunk.method_12004().method_8328(),
                chunk.method_12004().method_8327(), -41, chunk.method_12004().method_8329()
            );

            StructureData data = new StructureData(
                "Ancient City (Detected)", "minecraft:ancient_city", box, 0x191970
            );
            data.updateDistance(playerPos);
            found.add(data);
        }
    }

    /**
     * Heuristic detection for Trial Chambers based on Copper blocks.
     */
    private void detectTrialChambersByBlocks(class_2818 chunk, class_243 playerPos, List<StructureData> found, Set<String> seenKeys) {
        int copperCount = 0;
        int threshold = 15; // Minimum copper indicators to consider it a Trial Chamber

        class_2826[] sections = chunk.method_12006();
        for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
            class_2826 section = sections[sectionIndex];
            if (section == null || section.method_38292()) continue;
            
            // Trial Chambers are usually between Y -40 and Y 50
            int sectionY = chunk.method_31604(sectionIndex) << 4;
            if (sectionY < -40 || sectionY > 50) continue;

            for (int x = 0; x < 16; x += 2) {
                for (int y = 0; y < 16; y += 2) {
                    for (int z = 0; z < 16; z += 2) {
                        class_2680 state = section.method_12254(x, y, z);
                        if (state.method_27852(class_2246.field_47072) || state.method_27852(class_2246.field_47064) || 
                            state.method_27852(class_2246.field_47057) || state.method_27852(class_2246.field_47035)) {
                            copperCount++;
                        }
                    }
                }
            }
        }

        if (copperCount >= threshold) {
            String uniqueKey = "heuristic_trial_" + chunk.method_12004().field_9181 + "_" + chunk.method_12004().field_9180;
            if (seenKeys.contains(uniqueKey)) return;
            seenKeys.add(uniqueKey);

            class_3341 box = new class_3341(
                chunk.method_12004().method_8326(), 0, chunk.method_12004().method_8328(),
                chunk.method_12004().method_8327(), 20, chunk.method_12004().method_8329()
            );

            StructureData data = new StructureData(
                "Trial Chamber (Copper detected)", "minecraft:trial_chambers", box, 0xFF7F50
            );
            data.updateDistance(playerPos);
            found.add(data);
        }
    }

    /**
     * Scans for chests and other loot containers.
     */
    private void scanChestsInChunk(class_2818 chunk, class_243 playerPos, List<StructureData> found) {
        for (class_2586 entity : chunk.method_12214().values()) {
            if (entity instanceof class_2595 || entity instanceof class_3719 || entity instanceof class_2627) {
                
                class_2338 pos = entity.method_11016();
                class_3341 box = new class_3341(pos.method_10263(), pos.method_10264(), pos.method_10260(), pos.method_10263(), pos.method_10264(), pos.method_10260());
                
                StructureData data = new StructureData(
                    "Chest", "minecraft:chest", box, 0xFFAA00
                );
                data.updateDistance(playerPos);
                found.add(data);
            }
        }
    }

    /**
     * Attempt to resolve a Structure object to its registry ID string.
     */
    private String getStructureId(class_638 world, class_3195 structure) {
        try {
            var registry = world.method_30349()
                    .method_30530(net.minecraft.class_7924.field_41246);
            var id = registry.method_10221(structure);
            return id != null ? id.toString() : null;
        } catch (Exception e) {
            return null;
        }
    }

    public List<StructureData> getStructures() {
        return structures;
    }

    // Internal helper record
    private static class StructureInfo {
        final String name;
        final int color;

        StructureInfo(String name, int color) {
            this.name = name;
            this.color = color;
        }
    }
}
