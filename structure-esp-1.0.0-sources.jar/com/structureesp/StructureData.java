package com.structureesp;

import net.minecraft.class_243;
import net.minecraft.class_3341;

/**
 * Data holder for a detected structure.
 */
public class StructureData {

    private final String name;
    private final String registryKey;
    private final class_3341 boundingBox;
    private final class_243 center;
    private final int color;
    private double distanceToPlayer;

    public StructureData(String name, String registryKey, class_3341 boundingBox, int color) {
        this.name = name;
        this.registryKey = registryKey;
        this.boundingBox = boundingBox;
        this.color = color;

        // Calculate center of bounding box
        this.center = new class_243(
                (boundingBox.method_35415() + boundingBox.method_35418()) / 2.0,
                (boundingBox.method_35416() + boundingBox.method_35419()) / 2.0,
                (boundingBox.method_35417() + boundingBox.method_35420()) / 2.0
        );
    }

    public String getName() {
        return name;
    }

    public String getRegistryKey() {
        return registryKey;
    }

    public class_3341 getBoundingBox() {
        return boundingBox;
    }

    public class_243 getCenter() {
        return center;
    }

    public int getColor() {
        return color;
    }

    public float getRed() {
        return ((color >> 16) & 0xFF) / 255.0f;
    }

    public float getGreen() {
        return ((color >> 8) & 0xFF) / 255.0f;
    }

    public float getBlue() {
        return (color & 0xFF) / 255.0f;
    }

    public double getDistanceToPlayer() {
        return distanceToPlayer;
    }

    public void updateDistance(class_243 playerPos) {
        this.distanceToPlayer = playerPos.method_1022(center);
    }
}
