package com.structureesp;

import java.util.*;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Screen for choosing which blocks to show in X-Ray.
 */
public class XRayFilterScreen extends class_437 {
    private final class_437 parent;
    private final Map<String, String> commonBlocks = new LinkedHashMap<>();

    protected XRayFilterScreen(class_437 parent) {
        super(class_2561.method_43470("X-Ray Filter Settings"));
        this.parent = parent;
        
        commonBlocks.put("minecraft:diamond_ore", "Diamond Ore");
        commonBlocks.put("minecraft:deepslate_diamond_ore", "Deepslate Diamond");
        commonBlocks.put("minecraft:gold_ore", "Gold Ore");
        commonBlocks.put("minecraft:deepslate_gold_ore", "Deepslate Gold");
        commonBlocks.put("minecraft:iron_ore", "Iron Ore");
        commonBlocks.put("minecraft:deepslate_iron_ore", "Deepslate Iron");
        commonBlocks.put("minecraft:ancient_debris", "Ancient Debris (Netherite)");
        commonBlocks.put("minecraft:netherite_block", "Netherite Block");
        commonBlocks.put("minecraft:spawner", "Mob Spawner");
        commonBlocks.put("minecraft:emerald_ore", "Emerald Ore");
        commonBlocks.put("minecraft:deepslate_emerald_ore", "Deepslate Emerald");
        commonBlocks.put("minecraft:lapis_ore", "Lapis Ore");
        commonBlocks.put("minecraft:redstone_ore", "Redstone Ore");
        commonBlocks.put("minecraft:gilded_blackstone", "Gilded Blackstone");
        commonBlocks.put("minecraft:nether_gold_ore", "Nether Gold Ore");
        commonBlocks.put("minecraft:chest", "Chest");
        commonBlocks.put("minecraft:barrel", "Barrel");
    }

    @Override
    protected void method_25426() {
        int buttonWidth = 140;
        int buttonHeight = 20;
        int xOffset = 20;
        int yOffset = 40;
        int columns = 2;

        int i = 0;
        for (Map.Entry<String, String> entry : commonBlocks.entrySet()) {
            String id = entry.getKey();
            String name = entry.getValue();
            
            int col = i % columns;
            int row = i / columns;
            
            int x = this.field_22789 / 2 - (buttonWidth * columns + 10) / 2 + col * (buttonWidth + 10);
            int y = yOffset + row * (buttonHeight + 5);

            this.method_37063(class_4185.method_46430(getFilterText(id, name), button -> {
                ModConfig config = ModConfig.get();
                if (config.xrayFilter.contains(id)) {
                    config.xrayFilter.remove(id);
                } else {
                    config.xrayFilter.add(id);
                }
                config.save();
                button.method_25355(getFilterText(id, name));
                
                // If X-Ray is already on, reload to show changes immediately
                if (config.xrayEnabled && this.field_22787 != null && this.field_22787.field_1769 != null) {
                    this.field_22787.field_1769.method_3279();
                }
            })
            .method_46434(x, y, buttonWidth, buttonHeight)
            .method_46431());
            
            i++;
        }

        // Back Button
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Back"), button -> {
            this.field_22787.method_1507(this.parent);
        })
        .method_46434(this.field_22789 / 2 - 75, this.field_22790 - 30, 150, 20)
        .method_46431());
    }

    private class_2561 getFilterText(String id, String name) {
        boolean active = ModConfig.get().xrayFilter.contains(id);
        return class_2561.method_43470(name + ": " + (active ? "§aON" : "§cOFF"));
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        context.method_25300(this.field_22793, "§6§lSelect Blocks to Find", this.field_22789 / 2, 15, 0xFFFFFF);
        super.method_25394(context, mouseX, mouseY, delta);
    }
}
