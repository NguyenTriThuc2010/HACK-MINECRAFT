package com.structureesp.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_2791;
import net.minecraft.class_3195;
import net.minecraft.class_3449;

@Mixin(class_2791.class)
public interface ChunkAccessor {
    @Accessor("structureStarts")
    Map<class_3195, class_3449> getStructureStarts();
}
