package com.structureesp.mixin;

import com.structureesp.ModConfig;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4970.class_4971.class)
public abstract class AbstractBlockStateMixin {

    @Shadow
    public abstract class_2248 getBlock();

    @Inject(method = "getRenderType", at = @At("HEAD"), cancellable = true)
    private void onGetRenderType(CallbackInfoReturnable<class_2464> cir) {
        ModConfig config = ModConfig.get();
        if (config.xrayEnabled) {
            String blockId = class_7923.field_41175.method_10221(this.getBlock()).toString();
            if (!config.xrayFilter.contains(blockId)) {
                cir.setReturnValue(class_2464.field_11455);
            }
        }
    }

    @Inject(method = "getAmbientOcclusionLightLevel", at = @At("HEAD"), cancellable = true)
    private void onGetAmbientOcclusionLightLevel(CallbackInfoReturnable<Float> cir) {
        if (ModConfig.get().xrayEnabled) {
            cir.setReturnValue(1.0f);
        }
    }

    @Inject(method = "isOpaque", at = @At("HEAD"), cancellable = true)
    private void onIsOpaque(CallbackInfoReturnable<Boolean> cir) {
        if (ModConfig.get().xrayEnabled) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "getOpacity", at = @At("HEAD"), cancellable = true)
    private void onGetOpacity(CallbackInfoReturnable<Integer> cir) {
        if (ModConfig.get().xrayEnabled) {
            cir.setReturnValue(0);
        }
    }

    @Inject(method = "isFullCube", at = @At("HEAD"), cancellable = true)
    private void onIsFullCube(CallbackInfoReturnable<Boolean> cir) {
        if (ModConfig.get().xrayEnabled) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "isSideInvisible", at = @At("HEAD"), cancellable = true)
    private void onIsSideInvisible(class_2680 neighbor, class_2350 direction, CallbackInfoReturnable<Boolean> cir) {
        ModConfig config = ModConfig.get();
        if (config.xrayEnabled) {
            String blockId = class_7923.field_41175.method_10221(this.getBlock()).toString();
            // Critical fix: If THIS is an ore, it MUST render, so it's NEVER invisible
            if (config.xrayFilter.contains(blockId)) {
                cir.setReturnValue(false);
            } else {
                // If this is NOT an ore, it IS invisible if the neighbor is also NOT an ore
                String neighborId = class_7923.field_41175.method_10221(neighbor.method_26204()).toString();
                if (!config.xrayFilter.contains(neighborId)) {
                    cir.setReturnValue(true);
                }
            }
        }
    }
}
