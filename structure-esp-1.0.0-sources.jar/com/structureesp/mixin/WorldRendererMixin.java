package com.structureesp.mixin;

import com.structureesp.StructureESPMod;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin into WorldRenderer as a safety hook.
 * The actual rendering is done via Fabric API's WorldRenderEvents.LAST,
 * but this mixin ensures the mod loads and can serve as a fallback.
 */
@Mixin(class_761.class)
public class WorldRendererMixin {

    @Inject(method = "reload()V", at = @At("HEAD"))
    private void onReload(CallbackInfo ci) {
        StructureESPMod.LOGGER.info("[StructureESP] WorldRenderer reloaded — ESP active: {}",
                StructureESPMod.isEspEnabled());
    }
}
